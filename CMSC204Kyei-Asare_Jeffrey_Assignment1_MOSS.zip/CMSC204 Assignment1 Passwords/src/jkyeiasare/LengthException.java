package jkyeiasare;

public class LengthException extends Exception {
	private String message;

	public LengthException(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}

}
