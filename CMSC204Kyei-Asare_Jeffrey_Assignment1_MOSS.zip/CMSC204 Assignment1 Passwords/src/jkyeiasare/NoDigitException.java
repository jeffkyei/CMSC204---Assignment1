package jkyeiasare;

public class NoDigitException extends Exception {
	private String message;
	
	public NoDigitException(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}

	//how to write exception class
}
