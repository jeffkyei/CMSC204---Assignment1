package jkyeiasare;

public class NoSpecialCharacterException extends Exception {
	private String message;

	public NoSpecialCharacterException(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
}
