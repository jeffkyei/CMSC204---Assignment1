package jkyeiasare;

public class WeakPasswordException extends Exception {
	private String message;

	public WeakPasswordException(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}


}
