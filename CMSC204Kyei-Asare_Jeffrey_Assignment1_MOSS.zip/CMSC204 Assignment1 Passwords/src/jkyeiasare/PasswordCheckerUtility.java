package jkyeiasare;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PasswordCheckerUtility {
	
	//isValidLength -- DONE
	public static boolean isValidLength(String password) throws LengthException {  //Mini isValid length method
		
		boolean val = false; //test boolean
		
		if(password.length() > 6) {
			val = true;     //length is valid      
		}
		else {
			throw new LengthException("The password must be at least 6 characters long"); //Throw exception if too short
		}
		
		return val; //return true if valid length else throw exception
	}
	
	//hasDigit -- DONE
	public static boolean hasDigit(String password) throws NoDigitException{
		
		char ch = 'a'; //character to use to check for each character in password
		boolean check = false; //boolean to see if password has Digit
		
		for(int i = 0; i< password.length(); i ++) {
			ch = password.charAt(i);
			if(Character.isDigit(ch)) {
				check = true;
			}
		}
		if(check == true) {
			System.out.print(check);
			return check;
		}
		else {	
			throw new NoDigitException("The password must contain at least one digit");
		}

	}
	
	//has UpperCase Letter -- DONE
	public static boolean hasUpperAlpha(String password) throws NoUpperAlphaException{
		
		char ch = 'a'; //character to use to check for each character in password
		boolean check = false; //boolean to see if password has Digit
		for(int i = 0; i< password.length(); i++) {
			ch = password.charAt(i);
			if(Character.isLetter(ch)) { // if character is a letter
				if(Character.toUpperCase(ch) == ch) {
					check = true;
				}
			}
		}
		if(check == true) {
			return check;
		}
		else {
			throw new NoUpperAlphaException("The password must have an uppercase letter");
		}
		
	}
	
	//has Lowercase Letter -- DONE
	public static boolean hasLowerAlpha(String password) throws NoLowerAlphaException{
		char ch = 'a'; //character to use to check for each character in password
		boolean check = false; //boolean to see if password has Digit
		for(int i = 0; i< password.length(); i++) {
			ch = password.charAt(i);
			if(Character.isLetter(ch)) { // if character is a letter
				if(Character.toLowerCase(ch) == ch) {
					check = true;
				}
			}
		}
		if(check == true) {
			return check;
		}
		else {
			throw new NoLowerAlphaException("The password must contain at least one lowercase alphabetic character");
		}
		
	}

	
	//has Special Character
	public static boolean hasSpecialChar(String password) throws NoSpecialCharacterException{
		Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
		Matcher matcher = pattern.matcher(password);
		
		if(!matcher.matches() == false) {
			throw new NoSpecialCharacterException("The password must contain at least one special character");
		}
		
		return (!matcher.matches());
	}
	
	//Same character in sequence  -- DONE
	public static boolean NoSameCharInSequence(String password) throws InvalidSequenceException{
		boolean same = false;
		char ch = 'a';
		int count = 0;
		for(int i = 0; i< password.length()-2; i++) {
			if((password.charAt(i) == password.charAt(i+1)) && (password.charAt(i) == password.charAt(i+2))){
				same = true;
				throw new InvalidSequenceException("The password cannot contain more than two of the same character in sequence");
			}
		}
		
		return same;
	}
		
		
	//Check if password is valid but between 6-9 characters	-- DONE
	public static boolean isWeakPassword(String password) throws WeakPasswordException {
		boolean weak = true; //boolean val to see if password is weak
		
		try {
			if(isValidPassword(password) && (!hasBetweenSixAndNineChars(password))) {
				weak = false;
			}
			else {
				throw new WeakPasswordException("The password is OK but weak - it contains fewer than 10 characters");
			}
		} catch (LengthException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoUpperAlphaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoLowerAlphaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoDigitException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSpecialCharacterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidSequenceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (WeakPasswordException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return weak;
	}	
	
	
	//Check if between 6 and 9 characters -- DONE
	public static boolean hasBetweenSixAndNineChars(String password) {
		
		boolean weak = false;
		
		if(password.length() >= 6 && password.length() <= 9) { //if between 6-9 password weka
			weak = true;
		}
		
		return weak; //return true or false
	}
	
	//Check if passwords are the same with return -- DONE
	public static boolean comparePasswordsWithReturn(String password, String passwordConfirm){
		
		boolean theSame = true;   //check if passwords the same
		
		if(password.length() != passwordConfirm.length()) { //if passwords not the same length then theSame is false
			theSame = false;
		}
		else {
			for(int i = 0; i < password.length(); i++) {
				if(password.charAt(i) != passwordConfirm.charAt(i)) { //if characters not the same then theSame is false
					theSame = false;
				}
			}
		}
		return theSame;
	}
	
	//Compare passwords with exception -- DONE
	public static void comparePasswords(String password, String passwordConfirm) throws UnmatchedException{
		
		boolean theSame = true;   //check if passwords the same
		
		if(password.length() != passwordConfirm.length()) { //if passwords not the same length then theSame is false and throw exception
			throw new UnmatchedException("Passwords do not match");
		}
		else {
			for(int i = 0; i < password.length(); i++) {
				if(password.charAt(i) != passwordConfirm.charAt(i)) { //if characters not the same then throw exception
					throw new UnmatchedException("Passwords do not match");
				}
			}
		}
	}
	
	//isValidpassword
	public static boolean isValidPassword(String password) throws LengthException, NoUpperAlphaException, NoLowerAlphaException, NoDigitException, NoSpecialCharacterException, InvalidSequenceException {   //big isValidpassword Method
		boolean valid = true;
		if(isValidLength(password) == false) {
			valid = false;
			throw new LengthException("The password must be at least 6 characters long"); //Throw exception if too short
		}
		else if(hasDigit(password) == false) {
			valid = false;
			throw new NoDigitException("The password must contain at least one digit");
		}
		else if(hasUpperAlpha(password) == false) {
			valid = false;
			throw new NoUpperAlphaException("The password must have an uppercase letter");
		}
		else if(hasLowerAlpha(password) == false) {
			valid = false;
			throw new NoLowerAlphaException("The password must contain at least one lowercase alphabetic character");
		}else if(hasSpecialChar(password) == false) {
			valid = false;
			throw new NoSpecialCharacterException("The password must contain at least one special character");
		}else if(NoSameCharInSequence(password) == true) {
			valid = false;
			throw new InvalidSequenceException("The password cannot contain more than two of the same character in sequence");
		}
		
		return valid;
	}
		


	public static ArrayList<String> getInvalidPasswords(ArrayList<String> passwords){
		ArrayList<String> invalid = new ArrayList<String>();
		
		for(int i = 0; i < passwords.size(); i ++) {
			try {
				if(isValidPassword(passwords.get(i)) == false) { //if false, throws exception
					invalid.add(passwords.get(i));
				}
			} catch (LengthException e) {
				invalid.add(passwords.get(i) + " -> " + e.getMessage());
//				e.printStackTrace();
			} catch (NoUpperAlphaException e) {
				invalid.add(passwords.get(i) + " -> " + e.getMessage());
//				e.printStackTrace();
			} catch (NoLowerAlphaException e) {
				
				invalid.add(passwords.get(i) + " -> " + e.getMessage());
//				e.printStackTrace();
			} catch (NoDigitException e) {
				invalid.add(passwords.get(i) + " -> " + e.getMessage());
//				e.printStackTrace();
			} catch (NoSpecialCharacterException e) {				
				invalid.add(passwords.get(i) + " -> " + e.getMessage());
//				e.printStackTrace();
			} catch (InvalidSequenceException e) {
				invalid.add(passwords.get(i) + " -> " + e.getMessage());
//				e.printStackTrace();
			}
		}
		
		
		return invalid;
	}
		
		
}
