package jkyeiasare;

public class NoLowerAlphaException extends Exception {
	private String message;

	public NoLowerAlphaException(String message) {
		this.message = message;
	}
	public String getMessage() {
		return message;
	}

}
