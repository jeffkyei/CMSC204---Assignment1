package jkyeiasare;

public class UnmatchedException extends Exception {
	private String message;

	public UnmatchedException(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}

}
