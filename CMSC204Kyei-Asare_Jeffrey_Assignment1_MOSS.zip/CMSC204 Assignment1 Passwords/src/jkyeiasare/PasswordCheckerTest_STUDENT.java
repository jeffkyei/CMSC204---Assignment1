package jkyeiasare;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;




/**
 * STUDENT tests for the methods of PasswordChecker
 * @author 
 *
 */
public class PasswordCheckerTest_STUDENT {
	ArrayList<String> passwordsArray;
	String password = "Jeffrey123!";
	String passwordConfirm = "jeffrey123!";
	String allCaps = "JEFFREYKYEI";
	String withDigit = "Jeffrey1";
	
	@BeforeEach
	public void setUp() throws Exception {
		String[] p = {"11223344AA", "WeTheBest",withDigit,};
		passwordsArray = new ArrayList<String>();
		passwordsArray.addAll(Arrays.asList(p));
	}

	@AfterEach
	public void tearDown() throws Exception {
		passwordsArray = null;
	}

	/**
	 * Test if the password is less than 6 characters long.
	 * This test should throw a LengthException for second case.
	 */
	@Test
	public void testIsValidPasswordTooShort()
	{
		try {
			assertTrue(PasswordCheckerUtility.isValidLength("Jeff"));
		} catch (LengthException e) {
			e.printStackTrace();
		}
		try {
			assertFalse(PasswordCheckerUtility.isValidLength("Je123"));
		} catch (LengthException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Test if the password has at least one uppercase alpha character
	 * This test should throw a NoUpperAlphaException for second case
	 */
	@Test
	public void testIsValidPasswordNoUpperAlpha()
	{
		try {
			assertTrue(PasswordCheckerUtility.hasUpperAlpha("JeffreyUpper"));
		} catch (NoUpperAlphaException e) {
			e.printStackTrace();
		}
		try {
			assertFalse(PasswordCheckerUtility.hasUpperAlpha("jeffreyupper"));
		} catch (NoUpperAlphaException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Test if the password has at least one lowercase alpha character
	 * This test should throw a NoLowerAlphaException for second case
	 */
	@Test
	public void testIsValidPasswordNoLowerAlpha()
	{
		try {
			assertTrue(PasswordCheckerUtility.hasLowerAlpha("JeffreyLower"));
		} catch (NoLowerAlphaException e) {
			e.printStackTrace();
		}
		try {
			assertFalse(PasswordCheckerUtility.hasLowerAlpha("JEFFREYLOWER"));
		} catch (NoLowerAlphaException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Test if the password has more than 2 of the same character in sequence
	 * This test should throw a InvalidSequenceException for second case
	 */
	@Test
	public void testIsWeakPassword()
	{
		try {
			assertTrue(PasswordCheckerUtility.isWeakPassword("Jeff1!"));
		} catch (WeakPasswordException e) {
			e.printStackTrace();
		}
		try {
			assertFalse(PasswordCheckerUtility.isWeakPassword("Jeffrey123!"));
		} catch (WeakPasswordException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Test if the password has more than 2 of the same character in sequence
	 * This test should throw a InvalidSequenceException for second case
	 */
	@Test
	public void testIsValidPasswordInvalidSequence()
	{
		try {
			assertTrue(PasswordCheckerUtility.NoSameCharInSequence("Jefffrey"));
		} catch (InvalidSequenceException e) {
			e.printStackTrace();
		}
		try {
			assertFalse(PasswordCheckerUtility.NoSameCharInSequence("Jeffrey"));
		} catch (InvalidSequenceException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Test if the password has at least one digit
	 * One test should throw a NoDigitException
	 */
	@Test
	public void testIsValidPasswordNoDigit()
	{
		try {
			assertTrue(PasswordCheckerUtility.hasDigit("Jeffrey1"));
		} catch (NoDigitException e) {
			e.printStackTrace();
		}
		try {
			assertFalse(PasswordCheckerUtility.hasDigit("Jeffrey!"));
		} catch (NoDigitException e) {
			e.printStackTrace();
		}
	}
	
	/** **
	 * Test correct passwords
	 * This test should not throw an exception
	 */
	@Test
	public void testIsValidPasswordSuccessful()
	{
		try {
			assertTrue(PasswordCheckerUtility.isValidPassword("Jeffrey123!"));
		} catch (LengthException e) {
			e.printStackTrace();
		} catch (NoUpperAlphaException e) {
			e.printStackTrace();
		} catch (NoLowerAlphaException e) {
			e.printStackTrace();
		} catch (NoDigitException e) {
			e.printStackTrace();
		} catch (NoSpecialCharacterException e) {
			e.printStackTrace();
		} catch (InvalidSequenceException e) {
			e.printStackTrace();
		} 
	}
	
	/** **
	 * Test the invalidPasswords method
	 * Check the results of the ArrayList of Strings returned by the validPasswords method
	 */
	@Test
	public void testInvalidPasswords() {
		ArrayList<String> checker;
		checker = PasswordCheckerUtility.getInvalidPasswords(passwordsArray);
		assertEquals(checker.size(), 3);
	}
	
}

